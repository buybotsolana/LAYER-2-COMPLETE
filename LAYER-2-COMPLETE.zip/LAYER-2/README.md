# Solana Layer 2 - Documentazione Completa

## Panoramica

Questo pacchetto contiene l'implementazione completa di una soluzione Layer 2 per Solana con compatibilità Ethereum. Il sistema è progettato per offrire alta scalabilità (≥1.000 TPS), bassa latenza (≤5 ms) e sicurezza robusta, mantenendo la compatibilità con l'ecosistema Ethereum.

## Struttura del Pacchetto

Il pacchetto è organizzato nelle seguenti directory principali:

- `/onchain`: Programma Solana in Rust per la componente on-chain
- `/offchain`: Componenti JavaScript/TypeScript per l'infrastruttura off-chain
- `/bridge`: Implementazione del bridge Ethereum-Solana
- `/sdk`: SDK cross-platform per interagire con il Layer 2
- `/relayer`: Implementazione dei relayer per la verifica delle prove
- `/evm-compatibility`: Layer di compatibilità con EVM (Neon EVM, Eclipse)

## Componenti On-Chain

### Programma Principale (`lib.rs`)

Il punto di ingresso principale del programma Solana Layer 2, che gestisce il routing delle istruzioni ai moduli appropriati.

### Modulo di Verifica (`verification.rs`)

Gestisce la verifica delle prove e le sfide (challenges) per il bridge Ethereum-Solana Layer 2.

### Modulo Token Wrapped (`wrapped_token_mint.rs`)

Gestisce la creazione, il minting e il burning dei token wrapped su Solana.

### Modulo di Stato (`state.rs`)

Definisce le strutture dati e le funzioni di serializzazione/deserializzazione per il programma.

### Modulo di Errore (`error.rs`)

Definisce i tipi di errore personalizzati per il programma Solana Layer 2.

### Modulo di Sicurezza (`security.rs`)

Implementa funzionalità di sicurezza come rate limiting, amount limiting, protezione da replay e altre misure di sicurezza.

### Modulo Processore (`processor.rs`)

Implementa la logica di elaborazione principale per il programma Solana Layer 2, inclusa l'elaborazione delle transazioni, la gestione dei batch e le transizioni di stato.

## Componenti Off-Chain

### Sequencer

Componente responsabile dell'ordinamento delle transazioni e della creazione dei batch.

### Bridge

Implementa il bridge tra Ethereum e Solana Layer 2, gestendo il trasferimento di asset tra le due blockchain.

### Cache Manager

Gestisce la memorizzazione nella cache per migliorare le prestazioni del sistema.

### Relayer

Componente responsabile della trasmissione delle prove tra Ethereum e Solana.

## Bridge Ethereum-Solana

### TokenVault.sol

Smart contract Ethereum che blocca i token su Ethereum e emette eventi per il minting di token wrapped su Solana Layer 2.

### Standard Proof Format

Definisce il formato standard per le prove utilizzate nel bridge Ethereum-Solana Layer 2.

### Transaction Monitor

Monitora le transazioni su entrambe le blockchain per garantire la coerenza dello stato.

## Compatibilità EVM

### EVM Compatibility Layer

Layer che fornisce compatibilità con l'EVM per eseguire smart contract Ethereum su Solana Layer 2.

### Neon EVM Adapter

Adapter specifico per l'integrazione con Neon EVM su Solana.

### Eclipse EVM Adapter

Adapter specifico per l'integrazione con Eclipse EVM su Solana.

## SDK

L'SDK fornisce un'interfaccia unificata per interagire con il Layer 2 di Solana, supportando sia ambienti Node.js che browser.

### Funzionalità principali:

- Creazione e invio di transazioni
- Gestione del batching automatico
- Monitoraggio dello stato delle transazioni
- Interazione con il bridge Ethereum-Solana
- Verifica delle prove
- Gestione delle sfide (challenges)

## Requisiti di Sistema

### On-Chain
- Solana CLI v1.14.0 o superiore
- Rust 1.60.0 o superiore
- Solana Program Library (SPL)

### Off-Chain
- Node.js v16.0.0 o superiore
- TypeScript 4.5.0 o superiore
- Web3.js 1.7.0 o superiore
- @solana/web3.js 1.50.0 o superiore

## Installazione

### Programma On-Chain

1. Clona il repository
2. Naviga nella directory `onchain`
3. Compila il programma:
   ```
   cargo build-bpf
   ```
4. Distribuisci il programma su Devnet:
   ```
   ./deploy_devnet.sh
   ```

### Componenti Off-Chain

1. Naviga nella directory `offchain`
2. Installa le dipendenze:
   ```
   npm install
   ```
3. Configura le variabili d'ambiente:
   ```
   cp .env.example .env
   # Modifica .env con le tue configurazioni
   ```
4. Avvia i componenti:
   ```
   npm run start:sequencer
   npm run start:bridge
   npm run start:relayer
   ```

## Utilizzo dell'SDK

```javascript
// Importa l'SDK
const { Layer2Client } = require('solana-layer2-sdk');

// Inizializza il client
const client = new Layer2Client({
  rpcUrl: 'https://api.devnet.solana.com',
  layer2ProgramId: 'YOUR_PROGRAM_ID',
  bridgeAddress: 'YOUR_BRIDGE_ADDRESS'
});

// Invia una transazione
async function sendTransaction() {
  const tx = await client.createTransaction({
    recipient: 'RECIPIENT_ADDRESS',
    amount: 1000000000, // 1 SOL in lamports
  });
  
  const signature = await client.sendTransaction(tx);
  console.log('Transaction sent:', signature);
  
  // Attendi la conferma
  await client.waitForConfirmation(signature);
  console.log('Transaction confirmed!');
}

// Utilizza il bridge per trasferire asset da Ethereum a Solana
async function bridgeAssets() {
  const result = await client.bridge.lockEthereumAssets({
    ethereumToken: '0xYOUR_TOKEN_ADDRESS',
    amount: '1000000000000000000', // 1 token in wei
    recipient: 'SOLANA_RECIPIENT_ADDRESS'
  });
  
  console.log('Bridge transaction:', result);
}
```

## Sicurezza

Il sistema implementa diverse misure di sicurezza:

1. **Protezione da Replay**: Ogni transazione include un nonce univoco per prevenire attacchi di replay.
2. **Rate Limiting**: Limita il numero di transazioni che un utente può inviare in un determinato periodo di tempo.
3. **Amount Limiting**: Limita l'importo totale che un utente può trasferire in un determinato periodo di tempo.
4. **Verifica delle Prove**: Utilizza prove crittografiche per verificare la validità delle transazioni cross-chain.
5. **Meccanismo di Challenge**: Permette di contestare transazioni fraudolente con un sistema di risoluzione delle dispute.
6. **Pausa di Emergenza**: Il sistema può essere messo in pausa in caso di emergenza.

## Ottimizzazioni

Il sistema include diverse ottimizzazioni per migliorare le prestazioni:

1. **Batching**: Le transazioni vengono raggruppate in batch per ridurre il costo del gas su Ethereum.
2. **Caching**: Utilizza strategie di caching avanzate per ridurre la latenza.
3. **Parallelizzazione**: Elabora le transazioni in parallelo quando possibile.
4. **Compressione**: Comprime i dati per ridurre i costi di storage e trasmissione.
5. **Merkle Trees**: Utilizza Merkle trees per verificare efficientemente grandi set di transazioni.

## Licenza

Questo progetto è rilasciato sotto la licenza MIT. Vedi il file LICENSE per i dettagli.

## Contatti

Per domande o supporto, contattare:
- Email: support@solana-layer2.com
- GitHub: https://github.com/solana-layer2
- Discord: https://discord.gg/solana-layer2
